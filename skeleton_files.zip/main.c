

#include "input_token.h"
#include "expr.h"
#include "error.h"

main(int argc, char *argv[])
{int val;
   fpi = fopen( *++argv, "r" );
   val =  evaluate_expression();
   printf("result = %d\n", val );
}