//Skeleton file
//Author: Prof. Hing Leung, PhD, New Mexico State University
//Last modified: unknown

void error( int i );
/* print out the i-th error message and exit the program */